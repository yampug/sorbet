#include "tests/hello_cc.h"

int main() {
  yy::parser parse;
  return parse();
}
