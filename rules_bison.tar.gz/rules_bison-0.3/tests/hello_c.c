#include "tests/hello_c.h"

int main() {
 return yyparse();
}
