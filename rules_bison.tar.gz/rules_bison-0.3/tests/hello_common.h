#ifndef _HELLO_COMMON_H
#define _HELLO_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif

void hello_common();

#ifdef __cplusplus
}
#endif

#endif  // _HELLO_COMMON_H
