void hello_common() {}
